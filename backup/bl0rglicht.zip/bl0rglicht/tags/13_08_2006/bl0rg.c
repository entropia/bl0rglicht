#include <inttypes.h>
#include <string.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/eeprom.h>
#include <avr/wdt.h>
#include <util/delay.h>

#include <stdlib.h>
#include <string.h>

#include "pt.h" /* protothreads */

#include "buffer.h"
#include "uart.h"

#include "bl0rg.h"


/* timeticks - incremented in the interrupts */
volatile uint32_t timerticks;
volatile uint8_t lready = 0;

/* buffer for general purpose */
volatile char buffer[128];
volatile uint16_t encoder_value = 0;
volatile uint16_t old_encoder_value = 0x03;

/* protothreads */
static struct pt serloop_pt, encloop_pt;

int main (void)
{
	/* UCSRA &= ~ _BV(U2X); */		// no doublespeed for serial port
	uartInit();					// initialize UART (serial port)
	uartSetBaudRate(BAUDRATE);	// set UART speed to 9600 baud
	
	sendstring("\n\r");
	sendstring(VERSION_STRING);
	
	
    DDRA = 0xff;
	DDRB = 0xff;
	DDRC = 0xff;
	DDRD = 0xff;
	
	InitTimer();
	sei();
	
	PORTA = 0xff;
	PORTB = 0xff;
	PORTC = 0xff;
	PORTD = 0xff;
	
	eeprom_ok();
	eeprom_busy_wait();
	eeprom_read_block(&leds,laststate,24);
	
	sendstring("\n\r");
	/* play_eeprom(); */
	sendstring("ok\n\r");
	
	/* here goes protothreads */
	PT_INIT(&serloop_pt);
	PT_INIT(&encloop_pt);
	
	while(1) {
		serloop(&serloop_pt);
		encloop(&encloop_pt);
	}
}

#ifndef BL0RG_H
#define BL0RG_H

#define BAUDRATE 19200L
#define TCNT0_INIT (0xFF-CPUCLK/256/TICKRATE)

#endif /* BL0RG_H */
#include <avr/interrupt.h>
#include <util/delay.h>
#include "bl0rg.h"

void InitTimer(void)
{
	TCCR0 = _BV(CS00);   /* CPU-Takt */
	TIMSK = _BV(TOIE0);
}

SIGNAL (SIG_OVERFLOW0) 
{
    /* Interrupt Code */
	static uint8_t  encstat = 0, oencstat = 0;
    static uint16_t ledbit;
    static uint16_t ledtimer;
								 
    timerticks++;   // F�r andere Timeranwendungen

	/* check for encoder on pind 4 and 5 */

	DDRD = 0x00;
	encstat = (PIND >> 4) & 0x03;
	switch (oencstat) {
	case 0x00:
		if (encstat == 0x01) encoder_value++;
		if (encstat == 0x02) encoder_value--;
		break;
	case 0x01:
		if (encstat == 0x03) encoder_value++;
		if (encstat == 0x00) encoder_value--;
		break;
	case 0x02:
		if (encstat == 0x00) encoder_value++;
		if (encstat == 0x03) encoder_value--;
		break;
	case 0x03:
		if (encstat == 0x02) encoder_value++;
		if (encstat == 0x01) encoder_value--;
		break;
	}
	oencstat = encstat;
	
	DDRD = 0xff;

	/* end of check for encoder */

	if (ledtimer == 0)
	{
		ledbit = (ledbit+1) & 0x07;
	
		switch(ledbit)
		{
			case 0: 
				HandleLED(0);
				_delay_loop_2(1);
			case 1: 
				HandleLED(1);
				_delay_loop_2(2);
			case 2: 
				HandleLED(2);
				_delay_loop_2(4);
			case 3: 
				HandleLED(3);
				_delay_loop_2(8);
			case 4: 
				HandleLED(4);
				_delay_loop_2(16);
			case 5: 
				HandleLED(5);			
				ledtimer = 1;
				ledbit   = 5;
				break;
			case 6: 
				HandleLED(6);
				ledtimer = 2;
				break;
			case 7: 
				HandleLED(7);
				ledtimer = 4;
				break;
			case 8: 
				HandleLED(8);
				ledtimer = 8;
				break;
			case 9: 
				HandleLED(9);
				ledtimer = 16;
				break;
			case 10: 
				HandleLED(10);
				ledtimer = 32;
				break;
			case 11: 
				HandleLED(11);
				ledtimer = 64;
				break;
			case 12: 
				HandleLED(12);
				ledtimer = 128;
				break;
			case 13: 
				HandleLED(13);
				ledtimer = 256;			
				break;
		}
	}
    ledtimer--;      
}

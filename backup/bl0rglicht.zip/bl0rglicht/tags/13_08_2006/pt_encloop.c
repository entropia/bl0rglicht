#include <inttypes.h>
#include "bl0rg.h"

int encloop(struct pt *pt)
{
	PT_BEGIN(pt);
	while(1) {
		int i = 0;
		if (encoder_value != old_encoder_value) {
			for (i=0;i<24;i++)
				;//SetLed(i,encoder_value);
		}
		old_encoder_value = encoder_value;
		PT_YIELD(pt);
		// sendstring("barfoo\n\r");
	}
	PT_END(pt);
}

#include <inttypes.h>
#include <avr/io.h>

#include "bl0rg.h"

void SetLed(uint8_t index, uint8_t value)
{
	uint8_t sub_index = index / 8;
	for (uint8_t i = 0; i < 14; i++)
	{
		if (value  & _BV(i))
		{
			leds[sub_index*8+i] |=  _BV(index & 0x07);
		} else {
			leds[sub_index*8+i] &= ~_BV(index & 0x07);
		}
	}
}

inline void HandleLED(uint8_t ledbit)
{
	PORTA = leds[0+ ledbit];
	PORTC = leds[8+ ledbit];
	PORTB = leds[16+ledbit];
}

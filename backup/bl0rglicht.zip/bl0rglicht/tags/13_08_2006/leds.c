#include <inttypes.h>
#include <avr/io.h>

#include "bl0rg.h"

volatile uint8_t leds[33];

void SetLed(uint8_t index, uint16_t value)
{
	if (value > 32) value = (value*value)/32;
	//if (value > 0x0fff) value = 0x0fff;
	uint8_t sub_index = index / 8;
	for (uint8_t i = 0; i < 11; i++)
	{
		if (value  & _BV(i))
		{
			leds[sub_index*11+i] |=  _BV(index & 0x07);
		} else {
			leds[sub_index*11+i] &= ~_BV(index & 0x07);
		}
	}
}

inline void HandleLED(uint8_t ledbit)
{
	PORTA = leds[0+ ledbit];
	PORTC = leds[11+ledbit];
	PORTB = leds[22+ledbit];
}

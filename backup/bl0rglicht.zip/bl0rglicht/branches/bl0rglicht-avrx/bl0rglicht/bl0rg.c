#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <avr/io.h>
#include <avr/pgmspace.h>
#include <avr/interrupt.h>
#include <avrx.h>
#include "../AvrXSerialIO/AvrXSerialIo.h"
#include "bl0rg.h"

AVRX_GCC_TASK(Monitor,20,0);

AVRX_SIGINT(SIG_OVERFLOW0)
{
	IntProlog();
	TCNT0 += TCNT0_INIT;
	AvrXTimerHandler();
	Epilog();
}

AVRX_GCC_TASKDEF(serloop,76,1)
{
	TimerControlBlock timer;
	
//	InitSerial0(BAUD(BAUDRATE));
//	fdevopen(put_char0,get_c0,0);
	while(1) {
		printf_P(PSTR("This is your atmel atmega16 running AvrX!\n\r"));
		AvrXDelay(&timer,5*1000);
	}
}

int main(void)
{
	AvrXSetKernelStack(0);
	
	MCUCR = _BV(SE);
	TCNT0 = TCNT0_INIT;
	TCCR0 = (1<<CS02);
	TIMSK = _BV(TOIE0);
	
	AvrXRunTask(TCB(Monitor));
	AvrXRunTask(TCB(serloop));
	
	Epilog();
	while(1);
	
}


#include <inttypes.h>
#include <string.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/eeprom.h>
#include <avr/wdt.h>
#include <util/delay.h>

#include <stdlib.h>
#include <string.h>

#include "pt.h" /* protothreads */

#include "buffer.h"
#include "uart.h"

#define BAUDRATE 19200
// #define XTAL 16000000L

#define VERSION_STRING "bl0rgware firmware 0.1\n\r"

void sendint(uint8_t);
uint8_t hextoint(char);
uint8_t eeprom_ok(void);
void play_eeprom(void);
void record_eeprom(void);
void clear_eeprom(void);
void random_eeprom(void);

/* timeticks - incremented in the interrupts */
static volatile uint32_t timerticks;
volatile uint8_t lready = 0;

/* EEPROM data */
static uint8_t laststate[24] EEMEM;
static uint8_t eepromdata[20][24] EEMEM;

/* buffer for general purpose */
static char buffer[128];
static volatile uint8_t leds[42];
static uint16_t encoder_value = 0;
static uint16_t old_encoder_value = 0x03;

void SetLed(uint8_t index, uint8_t value)
{
	uint8_t sub_index = index / 8;
	for (uint8_t i = 0; i < 14; i++)
	{
		if (value  & _BV(i))
		{
			leds[sub_index*8+i] |=  _BV(index & 0x07);
		} else {
			leds[sub_index*8+i] &= ~_BV(index & 0x07);
		}
	}
}

static struct pt serloop_pt, encloop_pt;


void delay_ms(uint16_t ms)
{
        for(uint16_t i = 0; i <= ms; i++)
        {
                _delay_ms(1);
        }
}

void sendchar(char i)
{
	uartSendByte(i);
}

void sendstring(char* text)
{
	uint8_t i = 0;
	
	while (text[i] != 0) 
	{
		sendchar(text[i]);
		i++;
	}
}

void sendint(uint8_t i)
{
	char acount[2];
	itoa(i,acount,10);
	sendstring(acount);
}

/* only for use with recline()!
   this function doesn't block if no character is avaible! */
char recchar(void)
{
	// static int i = 0;
	// while((i = uartGetByte()) != -1);
	return((char)uartGetByte());
}

char *recline(void)
{
	int c = 0;

	while(!lready);
	// sendchar('!');
	while((buffer[c] = recchar()) != '\n') {
		sendchar(buffer[c]);
		c++;
	}
	buffer[c] = '\0';
	sendstring("\n\r");
	lready = 0; // we got the newline
	return(buffer);
}

void InitTimer(void)
{
	TCCR0 = _BV(CS00);   /* CPU-Takt */
	TIMSK = _BV(TOIE0);
}

void WaitTimerTicks(uint32_t ticks)
{
	timerticks = 0;
	while (timerticks <= ticks);
}

static int encloop(struct pt *pt)
{
	PT_BEGIN(pt);
	while(1) {
		int i = 0;
		if (encoder_value != old_encoder_value) {
			for (i=0;i<24;i++)
				;//SetLed(i,encoder_value);
		}
		old_encoder_value = encoder_value;
		PT_YIELD(pt);
		// sendstring("barfoo\n\r");
	}
	PT_END(pt);
}


/* the interactive serial i/o loop */
static int serloop(struct pt *pt)
{
	PT_BEGIN(pt);

	static uint8_t flag = 0;
	static uint8_t *randbuffer;
	static uint8_t c,led,i;

    while(1)
	{
		c = 0;
		led = 0;
		i = 0;
		
		/*
		sendint(encoder_value);
		sendstring("\n\r");
		*/
		
		memset(buffer,0x00,sizeof(char)*128);
	
		sendchar('!');
		/* we are not allowed to sleep in this function */
		PT_WAIT_UNTIL(pt,lready==1);
		recline();
		
		switch(buffer[c++]) {
		case '\r':
			continue;
			break;
		case 'a':
		case 'A':
			eeprom_ok();
			eeprom_write_block(&leds,laststate,24);
		case 's':
		case 'S':
			while(buffer[c] && buffer[c+1]) {
				SetLed(led++,hextoint(buffer[c])*16 + hextoint(buffer[c+1]));
				c+=2;
			}
			break;
		case 'c':
		case 'C':
			if (buffer[c] == 'e') 
				clear_eeprom();
			else {
				for(uint8_t i = 0; i<24; ++i)
					SetLed(i,0);
				memset(buffer,0x00,sizeof(char)*128);
			}
			break;
		case 'f':
		case 'F':
			for(uint8_t i = 0; i<24; ++i)
				SetLed(i,255);
			memset(buffer,0xff,sizeof(char)*128);
			break;
		case 'i':
		case 'I':
			sendstring(VERSION_STRING);
			break;
		case 'r':
		case 'R':
			if (!flag) {
				for(uint8_t i=0,f=0; i<24; ++i) {
					if (f) {
						SetLed(i,0);
						++f;
					} else {
						SetLed(i,255);
						--f;
					}
				}
				flag++;
			} else {
				for(uint8_t i=0,f=0; i<24; ++i) {
					if (!f) {
						SetLed(i,0);
						--f;
					} else {
						SetLed(i,255);
						++f;
					}
				}
				flag--;
			}
			break;
		case 'e':
		case 'E':
			if (buffer[c] == 'r' || buffer[c] == 'R')
				record_eeprom();
			else if (buffer[c] == 'p' || buffer[c] == 'P')
				play_eeprom();
			else
				sendstring("r or p\n\r");
			break;
		case 'y':
		case 'Y':
			random_eeprom();
			break;
		case 'w':
		case 'W':
			randbuffer = malloc(24);
			if (randbuffer != NULL)
			{
				srand(128);
				for(;;) {
					for(i=0;i<24;i++) {
						randbuffer[i] = rand();
					}
					memcpy(&leds,randbuffer,24);
					delay_ms(100);
				}
				free(randbuffer);
			} else 
				sendstring("memory low\n\r");
			break;
		case 'z':
		case 'Z':
			for(;;)
				play_eeprom();
		default:
			sendstring("Unknown command\n\r");
		}
	}
	PT_END(pt);
}

int main (void)
{
	/* UCSRA &= ~ _BV(U2X); */		// no doublespeed for serial port
	uartInit();					// initialize UART (serial port)
	uartSetBaudRate(BAUDRATE);	// set UART speed to 9600 baud
	
	sendstring("\n\r");
	sendstring(VERSION_STRING);
	
	
    DDRA = 0xff;
	DDRB = 0xff;
	DDRC = 0xff;
	DDRD = 0xff;
	
	InitTimer();
	sei();
	
	PORTA = 0xff;
	PORTB = 0xff;
	PORTC = 0xff;
	PORTD = 0xff;
	
	/* 
	eeprom_ok();
	eeprom_busy_wait();
	eeprom_read_block(&leds,laststate,24);
	*/
	
	sendstring("\n\r");
	/* play_eeprom(); */
	sendstring("ok\n\r");
	
	/* here goes protothreads */
	PT_INIT(&serloop_pt);
	PT_INIT(&encloop_pt);
	
	while(1) {
		serloop(&serloop_pt);
		encloop(&encloop_pt);
	}
}

uint8_t hextoint(char c)
{
	if (c >= 'A' && c <= 'F')
		return(c-'A'+10);
	else if (c >= 'a' && c <= 'f')
		return(c-'a'+10);
	else if (c >= '0' && c <= '9')
		return(c-'0');
	else
		return(0);
}


inline void HandleLED(uint8_t ledbit)
{
	PORTA = leds[0+ ledbit];
	PORTC = leds[8+ ledbit];
	PORTB = leds[16+ledbit];
}


SIGNAL (SIG_OVERFLOW0) 
{
    /* Interrupt Code */
	static uint8_t  encstat = 0, oencstat = 0;
    static uint16_t ledbit;
    static uint16_t ledtimer;
								 
    timerticks++;   // F�r andere Timeranwendungen

	/* check for encoder on pind 4 and 5 */

	DDRD = 0x00;
	encstat = (PIND >> 4) & 0x03;
	switch (oencstat) {
	case 0x00:
		if (encstat == 0x01) encoder_value++;
		if (encstat == 0x02) encoder_value--;
		break;
	case 0x01:
		if (encstat == 0x03) encoder_value++;
		if (encstat == 0x00) encoder_value--;
		break;
	case 0x02:
		if (encstat == 0x00) encoder_value++;
		if (encstat == 0x03) encoder_value--;
		break;
	case 0x03:
		if (encstat == 0x02) encoder_value++;
		if (encstat == 0x01) encoder_value--;
		break;
	}
	oencstat = encstat;
	
	DDRD = 0xff;

	/* end of check for encoder */

	if (ledtimer == 0)
	{
		ledbit = (ledbit+1) & 0x07;
	
		switch(ledbit)
		{
			case 0: 
				HandleLED(0);
				_delay_loop_2(1);
			case 1: 
				HandleLED(1);
				_delay_loop_2(2);
			case 2: 
				HandleLED(2);
				_delay_loop_2(4);
			case 3: 
				HandleLED(3);
				_delay_loop_2(8);
			case 4: 
				HandleLED(4);
				_delay_loop_2(16);
			case 5: 
				HandleLED(5);			
				ledtimer = 1;
				ledbit   = 5;
				break;
			case 6: 
				HandleLED(6);
				ledtimer = 2;
				break;
			case 7: 
				HandleLED(7);
				ledtimer = 4;
				break;
			case 8: 
				HandleLED(8);
				ledtimer = 8;
				break;
			case 9: 
				HandleLED(9);
				ledtimer = 16;
				break;
			case 10: 
				HandleLED(10);
				ledtimer = 32;
				break;
			case 11: 
				HandleLED(11);
				ledtimer = 64;
				break;
			case 12: 
				HandleLED(12);
				ledtimer = 128;
				break;
			case 13: 
				HandleLED(13);
				ledtimer = 256;			
				break;
		}
	}
    ledtimer--;      
}

uint8_t eeprom_ok(void)
{
	if (eeprom_is_ready()) {
		return(1);
	} else {
		sendstring("eeprom not ready\n\r");
		return(0);
	}
}

void play_eeprom(void)
{
	uint8_t i = 0;
	uint8_t *s = eepromdata[0];
	
	eeprom_ok(); /* generate a warning if eeprom is not ready */
	eeprom_busy_wait();
		
	for(i = 0; i<20;i++) {
		eeprom_read_block(&leds,s,24);
		s+=24;
		delay_ms(100.0);
	}
}

void record_eeprom(void)
{
	uint8_t c = 0, led = 0;
	uint8_t counter = 1;
	uint8_t *ee = eepromdata[0];
	
	eeprom_ok();
	eeprom_busy_wait();
	/* check if eeprom is ready */
/*
	if (!eeprom_ok())
		return;
*/	
	
	sendstring("prog. eeprom(exit with x)\n\r");
	sendint(counter);
	sendchar(' ');
	sendchar('!');
	
	recline();
	
	while(counter <= 20) {
		c = 0;
		
		recline();
		
		if (buffer[c] == 'x' || buffer[c] == 'X')
			return;
	
		/* should the prelude be printed for next loop-run */
		counter++;
		if (counter <= 20) {
			sendint(counter);
			if (counter<10)
				sendchar(' ');
			sendchar('!');
		}
	
		led = 0;
		while(buffer[c] && buffer[c+1]) {
			leds[led++] = hextoint(buffer[c])*16 + hextoint(buffer[c+1]);
			c+=2;
		}
		eeprom_write_block(&leds,ee,24);
		ee += 24;
	}
}

void clear_eeprom(void)
{
	int i = 0;
	uint8_t *ee = eepromdata[0];
	
	sendstring("clearing eeprom\n\r");
	eeprom_ok();
	eeprom_busy_wait();
	
	for (i=0;i<24*20;++i) {
		eeprom_write_byte(ee,0);
		ee++;
	}
	
	ee = laststate;
	for (i=0;i<24;++i) {
		eeprom_write_byte(ee,0);
		ee++;
	}
}

void random_eeprom(void)
{
	int c = 0, i = 0;
	uint8_t lleds[24];
	uint8_t *ee = eepromdata[0];
	
	srand(128);
	for(c=0;c<20;++c) {
		for(i=0;i<24;++i)
			lleds[i] = rand();
		memcpy(&leds,lleds,24);
		eeprom_write_block(&leds,ee,24);
		ee+=24;
		delay_ms(10);
	}
}

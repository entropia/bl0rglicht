#include <inttypes.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/signal.h>
#include <avr/delay.h>
#include <avr/signal.h>


volatile uint8_t leds[24];


void switchled(int);

void delay_ms(uint16_t ms)
{
	for(uint16_t i = 0; i <= ms; i++)
	{
		_delay_ms(1);
	}
}

void InitTimer(void)
{
	TCCR0 = _BV(CS00);   // CPU-Takt/256
	TIMSK = _BV(TOIE0);
}



volatile uint16_t timerticks;

SIGNAL (SIG_OVERFLOW0)
{
    /* Interrupt Code */
	static uint16_t ledticks;
	
	timerticks++;
	
	ledticks++;
	if (ledticks > 255) 
	{
		ledticks = 0;
		PORTA = 0xFF;
		PORTB = 0xFF;
		PORTC = 0xFF;
	}
	
	for(uint8_t i = 0; i < 7; i++)
	{
		if (leds[i] <= ledticks)
		{
			PORTA &= ~_BV(i);
		}
		if (leds[i+8] <= ledticks)
		{
			PORTB &= ~_BV(i);
		}
		if (leds[i+16] <= ledticks)
		{
			PORTC &= ~_BV(i);
		}
	}
}

void WaitTimerTicks(uint16_t ticks)
{
	timerticks = 0;
	while (timerticks <= ticks);
}

int main (void)
{
	uint8_t status = 0;
	
    DDRA = 0xff;
	DDRB = 0xff;
	DDRC = 0xff;
	DDRD = 0xff;
	
	for(int i=0;i<24;i++)
	{
		leds[i] = 0x80;
	}   
	InitTimer();
	sei();
	
    for (;;) 
	{
		for(int i=0;i<255;i++){
			leds[0] = i;
			leds[8] = 255-i;
			leds[16] = abs(128-i);
			WaitTimerTicks(50);
		}   
	}
}

void switchled(int status)
{
	switch(status) {
		case 0:  PORTA = 0xff;
				  PORTB = 0x00;
				  PORTC = 0x00;
		          break;
		case 1:  PORTB = 0xff;
		          PORTA = 0x00;
				  PORTC = 0x00;
				  break;
		case 2:  PORTC = 0xff;
			      PORTA = 0x00;
				  PORTB = 0x00;
		          break;
	} 
		
}	